const express = require('express');
const multer = require('multer');
const Post = require('../models/post');

const router = express.Router();

const MIME_TYPE_MAP = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/jpg": "jpg"
}

const storage = multer.diskStorage({
  destination: (req, file, callback)=> {
    const isValid = MIME_TYPE_MAP[file.mimetype];
    let error = new Error("Invalid mime type");
    if(isValid){
      error= null;
    }
    console.log('callback');
    callback(error, "backend/images");
  },
  filename: (req, file, callback)=>{
    const name = file.originalname.toLowerCase().split(' ').join('-');
    const ext = MIME_TYPE_MAP[file.mimetype];
    callback(null, name +'-'+ Date.now()+'.'+ ext)
  }
});

router.post("", multer({storage:storage}).single("image"), (req, res, next)=>{
  const url = req.protocol + '://'+ req.get("host");
  const post = new Post({
    title: req.body.title,
    content: req.body.content,
    imagePath: url + "/images/" + req.file.filename
  });
  post.save()
  .then(createdPost=>{
    res.status(201).json({
      message: 'Post added',
      post:{

        ...createdPost, //spread operator для айтемов
        id: createdPost._id
        // title: createdPost.title,
        // content: createdPost.content,
        // imagePath: createdPost.imagePath
      }
    });
  });


});
router.put('/:id',  multer({storage:storage}).single("image"), (req, res, next)=>{ //просто так обновить не удасться, нужно перезаписывать и удалять старый пост

  let imagePath= req.body.imagePath;
  console.log(req.body.imagePath)
  if(req.file){

    const url = req.protocol + '://'+ req.get("host");
    imagePath=url + "/images/" + req.file.filename;

  }
  console.log(req.file);
  const post = new Post({
  _id: req.body.id,
  title: req.body.title,
  content: req.body.content,
  imagePath: imagePath
 })
 console.log(post)
  Post.updateOne({_id: req.params.id}, post)
  .then(result => {
    console.log(result);
    console.log("IUPDATED");
    res.status(200).json({message: 'Update succesfull'})
  })
});
router.get('',(req,res,next)=>{
  const pageSize = +req.query.pagesize;
  const currentPage = +req.query.page;
  const postQuery = Post.find();
  let fetchedPosts;
  if(pageSize && currentPage) {
    postQuery
    .skip(pageSize * (currentPage - 1))
    .limit(pageSize);
  }
  postQuery
  .then((documents)=>{
    fetchedPosts = documents;
  return Post.count();
  // res.status(200).json({
  //   message: 'Posts are fetched',
  //   posts: documents
  }
  ).then(count=>{
      res.status(200).json({
    message: 'Posts are fetched',
    posts: fetchedPosts,
    maxPosts: count
  });
});
  // const posts=[
  //   {id:'1231',
  //   title: 'First title',
  //    content: 'this is from server'},
  //    {id:'121431',
  //    title: 'Second title',
  //     content: 'this is from server #2'}
  // ];

});
router.get('/:id', (req,res,next)=>{
 Post.findById(req.params.id).then(post=>{
  if(post) {
    res.status(200).json(post);
  } else{
    res.status(404).json({message:"no Post"});
  }
 })
});
router.delete('/:id',(req,res,next)=>{
  Post.deleteOne({_id:req.params.id})
  .then(result=>console.log(result));
  console.log(req.params.id);
  res.status(200).json({message:'Post deleted'})
});


module.exports = router;
